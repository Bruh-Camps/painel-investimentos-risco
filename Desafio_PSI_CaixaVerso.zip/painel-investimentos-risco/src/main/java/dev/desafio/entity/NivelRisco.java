package dev.desafio.entity;

/**
 * Nível de risco do investimento.
 */
public enum NivelRisco {
    BAIXO,
    MEDIO,
    ALTO
}
